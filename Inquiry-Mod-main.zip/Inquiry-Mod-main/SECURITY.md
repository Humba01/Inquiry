# Security Policy

## Minecraft Versões Suportadas:

| Version | Supported          |
| ------- | ------------------ |
| 1.16.x  | :x:                |
| 1.16.4  | :white_check_mark: |
| 1.17.x  | :x:                |
