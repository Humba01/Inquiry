# Inquiry Mod 

*Essa modificação usa FabricMC API*

_Número total de Items e Blocos adicionados ===> 224._
