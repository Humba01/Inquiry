
## Changelog v0.1.1 - Minecraft JE 1.16.4 _=_ 13/01/2021

=> Atualizações nas texturas dos minérios.

## Changelog v0.1.0 - Minecraft JE 1.16.4 _=_ 13/01/2021

### 24 Novos Minérios (Grupo 1)

- Steel Ore;
- Tin Ore;
- Aluminum Ore;
- Titanium Ore;
- Bismuth Ore;
- Silver Ore;
- Cooper Ore;
- Cadmium Ore;
- Cooper Ore;
- Cobalt Ore;
- Chrome Ore;
- Iridium Ore;
- Osmium Ore;
- Nickel Ore;
- Lead Ore;
- Thallium Ore;
- Indian Ore;
- Bronze Ore;
- Brass Ore;
- Invar Ore;
- Tombac Ore;
- Nichrome Ore;
- Electron Ore;

### 24 Novos Blocos de Minério (Grupo 1)

- Steel Block;
- Tin Block;
- Aluminum Block;
- Titanium Block;
- Bismuth Block;
- Silver Block;
- Cooper Block;
- Cadmium Block;
- Cooper Block;
- Cobalt Block;
- Chrome Block;
- Iridium Block;
- Osmium Block;
- Nickel Block;
- Lead Block;
- Thallium Block;
- Indian Block;
- Bronze Block;
- Brass Block;
- Invar Block;
- Tombac Block;
- Nichrome Block;
- Electron Block;

### 24 Novas Barras de Minério (Grupo 1)

- Steel Ingot;
- Tin Ingot;
- Aluminum Ingot;
- Titanium Ingot;
- Bismuth Ingot;
- Silver Ingot;
- Cooper Ingot;
- Cadmium Ingot;
- Cooper Ingot;
- Cobalt Ingot;
- Chrome Ingot;
- Iridium Ingot;
- Osmium Ingot;
- Nickel Ingot;
- Lead Ingot;
- Thallium Ingot;
- Indian Ingot;
- Bronze Ingot;
- Brass Ingot;
- Invar Ingot;
- Tombac Ingot;
- Nichrome Ingot;
- Electron Ingot;

### 26 Novos Gravetos

- Stone Stick;
- Iron Stick;
- Steel Stick;
- Tin Stick;
- Aluminum Stick;
- Titanium Stick;
- Bismuth Stick;
- Silver Stick;
- Cooper Stick;
- Cadmium Stick;
- Cooper Stick;
- Cobalt Stick;
- Chrome Stick;
- Iridium Stick;
- Osmium Stick;
- Nickel Stick;
- Lead Stick;
- Thallium Stick;
- Indian Stick;
- Bronze Stick;
- Brass Stick;
- Invar Stick;
- Tombac Stick;
- Nichrome Stick;
- Electron Stick;

### 24 Novas Espadas

- Steel Sword;
- Tin Sword;
- Aluminum Sword;
- Titanium Sword;
- Bismuth Sword;
- Silver Sword;
- Cooper Sword;
- Cadmium Sword;
- Cooper Sword;
- Cobalt Sword;
- Chrome Sword;
- Iridium Sword;
- Osmium Sword;
- Nickel Sword;
- Lead Sword;
- Thallium Sword;
- Indian Sword;
- Bronze Sword;
- Brass Sword;
- Invar Sword;
- Tombac Sword;
- Nichrome Sword;
- Electron Sword;

### 24 Novos Machados

- Steel Axe;
- Tin Axe;
- Aluminum Axe;
- Titanium Axe;
- Bismuth Axe;
- Silver Axe;
- Cooper Axe;
- Cadmium Axe;
- Cooper Axe;
- Cobalt Axe;
- Chrome Axe;
- Iridium Axe;
- Osmium Axe;
- Nickel Axe;
- Lead Axe;
- Thallium Axe;
- Indian Axe;
- Bronze Axe;
- Brass Axe;
- Invar Axe;
- Tombac Axe;
- Nichrome Axe;
- Electron Axe;

### 24 Novas Picaretas

- Steel Pickaxe;
- Tin Pickaxe;
- Aluminum Pickaxe;
- Titanium Pickaxe;
- Bismuth Pickaxe;
- Silver Pickaxe;
- Cooper Pickaxe;
- Cadmium Pickaxe;
- Cooper Pickaxe;
- Cobalt Pickaxe;
- Chrome Pickaxe;
- Iridium Pickaxe;
- Osmium Pickaxe;
- Nickel Pickaxe;
- Lead Pickaxe;
- Thallium Pickaxe;
- Indian Pickaxe;
- Bronze Pickaxe;
- Brass Pickaxe;
- Invar Pickaxe;
- Tombac Pickaxe;
- Nichrome Pickaxe;
- Electron Pickaxe;

### 24 Novas Pás

- Steel Shovel;
- Tin Shovel;
- Aluminum Shovel;
- Titanium Shovel;
- Bismuth Shovel;
- Silver Shovel;
- Cooper Shovel;
- Cadmium Shovel;
- Cooper Shovel;
- Cobalt Shovel;
- Chrome Shovel;
- Iridium Shovel;
- Osmium Shovel;
- Nickel Shovel;
- Lead Shovel;
- Thallium Shovel;
- Indian Shovel;
- Bronze Shovel;
- Brass Shovel;
- Invar Shovel;
- Tombac Shovel;
- Nichrome Shovel;
- Electron Shovel;

### 24 Novas Enxadas

- Steel Hoe;
- Tin Hoe;
- Aluminum Hoe;
- Titanium Hoe;
- Bismuth Hoe;
- Silver Hoe;
- Cooper Hoe;
- Cadmium Hoe;
- Cooper Hoe;
- Cobalt Hoe;
- Chrome Hoe;
- Iridium Hoe;
- Osmium Hoe;
- Nickel Hoe;
- Lead Hoe;
- Thallium Hoe;
- Indian Hoe;
- Bronze Hoe;
- Brass Hoe;
- Invar Hoe;
- Tombac Hoe;
- Nichrome Hoe;
- Electron Hoe;

### 6 Novas Bancadas de Trabalho Extendidas

! P.S ! -> You still don't have GUIs on any of the Workbenches.

- Extended Crafting Table Tier 1;
- Extended Crafting Table Tier 2;
- Extended Crafting Table Tier 3;
- Extended Crafting Table Tier 4;
- Extended Crafting Table Tier 5;
- Extended Crafting Table Tier 6;
