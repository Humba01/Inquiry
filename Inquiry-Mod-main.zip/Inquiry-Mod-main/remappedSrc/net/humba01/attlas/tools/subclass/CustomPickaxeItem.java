package net.humba01.attlas.tools.subclass;

import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ToolMaterial;

public class CustomPickaxeItem extends PickaxeItem {

  public CustomPickaxeItem(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
    super(material, attackDamage, attackSpeed, settings);
    // TODO Auto-generated constructor stub
  }
  
}
